"""Convert a PM2.5 concentration (ug/m3) into an AQI value and category.

Uses the Indian CPCB sub-index breakpoints for PM2.5 (24-hour basis).
Applying them to an hourly value is an approximation, but it's what makes the
model output readable to a human: "312, Very Poor" means more than "153.4".
"""
from __future__ import annotations

# (conc_low, conc_high, aqi_low, aqi_high, label)
BREAKPOINTS = [
    (0, 30, 0, 50, "Good"),
    (30, 60, 51, 100, "Satisfactory"),
    (60, 90, 101, 200, "Moderate"),
    (90, 120, 201, 300, "Poor"),
    (120, 250, 301, 400, "Very Poor"),
    (250, 1000, 401, 500, "Severe"),
]


def pm25_to_aqi(conc: float) -> tuple[int, str]:
    conc = max(float(conc), 0.0)
    for c_lo, c_hi, a_lo, a_hi, label in BREAKPOINTS:
        if c_lo <= conc <= c_hi:
            aqi = a_lo + (a_hi - a_lo) * (conc - c_lo) / (c_hi - c_lo)
            return round(aqi), label
    return 500, "Severe"


def advice(label: str) -> str:
    return {
        "Good": "Air is clean. Normal outdoor activity.",
        "Satisfactory": "Fine for most people; very sensitive groups may notice mild discomfort.",
        "Moderate": "Discomfort possible for people with asthma or heart conditions.",
        "Poor": "Breathing discomfort for most people on prolonged exposure. Limit outdoor exertion.",
        "Very Poor": "Respiratory illness on prolonged exposure. Avoid outdoor activity; use a mask.",
        "Severe": "Serious health effects for everyone. Stay indoors, keep windows shut.",
    }[label]


if __name__ == "__main__":
    for c in [12, 45, 75, 110, 180, 320]:
        aqi, label = pm25_to_aqi(c)
        print(f"{c:>5} ug/m3 -> AQI {aqi:>3}  {label:<13} {advice(label)}")
