"""Step 5 — use the saved model.

Predicts the next hour's PM2.5 from the most recent data, and also does a
recursive multi-hour forecast (each prediction is fed back in as a lag).

Run:  python src/predict.py --hours 6
"""
from __future__ import annotations

import argparse

import joblib
import pandas as pd

from aqi import advice, pm25_to_aqi
from config import MODELS, TARGET
from data import load_raw
from features import build_dataset


def load_model():
    path = MODELS / "best_model.joblib"
    if not path.exists():
        raise SystemExit("No saved model. Run `python src/train.py` first.")
    return joblib.load(path)


def forecast(hours: int = 6) -> pd.Series:
    bundle = load_model()
    model, feature_names = bundle["model"], bundle["features"]

    history = load_raw()
    preds = {}

    for step in range(hours):
        X, _, _ = build_dataset(history, horizon=0)
        row = X.iloc[[-1]].reindex(columns=feature_names, fill_value=0)
        value = float(model.predict(row)[0])

        next_time = history.index[-1] + pd.Timedelta(hours=1)
        preds[next_time] = value

        # Append the prediction and carry weather forward, so the next step
        # has a row to build lags from. (Real deployment: use a weather forecast.)
        new_row = history.iloc[-1].copy()
        new_row[TARGET] = value
        history = pd.concat([history, pd.DataFrame([new_row], index=[next_time])])

    return pd.Series(preds, name="predicted_pm25")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--hours", type=int, default=6, help="how many hours ahead")
    args = ap.parse_args()

    bundle = load_model()
    series = forecast(args.hours)

    print(f"Model: {bundle['name']}\n")
    print(f"{'time':<20}{'PM2.5':>9}{'AQI':>7}  category")
    print("-" * 52)
    for ts, value in series.items():
        a, label = pm25_to_aqi(value)
        print(f"{ts:%Y-%m-%d %H:%M}    {value:>9.1f}{a:>7}  {label}")

    worst = max(pm25_to_aqi(v) for v in series)
    print(f"\n{advice(worst[1])}")
    print("\nNote: accuracy drops sharply past ~3 hours, because each step "
          "feeds its own prediction back in as an input.")


if __name__ == "__main__":
    main()
