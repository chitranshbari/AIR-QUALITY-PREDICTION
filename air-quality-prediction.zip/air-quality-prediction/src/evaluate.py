"""Step 4 — look at the errors, not just the score.

Run:  python src/evaluate.py     (after train.py)
"""
from __future__ import annotations

import joblib
import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from config import MODELS, REPORTS


def load_predictions() -> pd.DataFrame:
    path = REPORTS / "test_predictions.csv"
    if not path.exists():
        raise SystemExit("Run `python src/train.py` first.")
    return pd.read_csv(path, index_col=0, parse_dates=True)


def plot_timeseries(df: pd.DataFrame, days: int = 14) -> None:
    window = df.iloc[: days * 24]
    fig, ax = plt.subplots(figsize=(13, 4.5))
    ax.plot(window.index, window["actual"], label="Actual", lw=1.6)
    ax.plot(window.index, window["predicted"], label="Predicted", lw=1.4, alpha=0.85)
    ax.set_title(f"Predicted vs actual PM2.5 — first {days} days of the test set")
    ax.set_ylabel("PM2.5 (ug/m3)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(REPORTS / "timeseries.png", dpi=130)
    plt.close(fig)


def plot_scatter_and_residuals(df: pd.DataFrame) -> None:
    resid = df["predicted"] - df["actual"]
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.2))

    lim = float(max(df["actual"].max(), df["predicted"].max()))
    axes[0].scatter(df["actual"], df["predicted"], s=4, alpha=0.25)
    axes[0].plot([0, lim], [0, lim], "r--", lw=1)
    axes[0].set(xlabel="Actual", ylabel="Predicted", title="Predicted vs actual")

    axes[1].hist(resid, bins=60)
    axes[1].axvline(0, color="r", ls="--", lw=1)
    axes[1].set(xlabel="Prediction - actual", title=f"Residuals (mean {resid.mean():.2f})")

    axes[2].scatter(df["actual"], resid, s=4, alpha=0.25)
    axes[2].axhline(0, color="r", ls="--", lw=1)
    axes[2].set(xlabel="Actual PM2.5", ylabel="Residual",
                title="Error grows at high pollution")

    fig.tight_layout()
    fig.savefig(REPORTS / "residuals.png", dpi=130)
    plt.close(fig)


def plot_importance(df: pd.DataFrame, top_n: int = 18) -> None:
    """Permutation importance on a sample — works for any model type."""
    from sklearn.inspection import permutation_importance

    from data import load_raw
    from features import build_dataset, chronological_split
    from config import TEST_FRACTION

    bundle = joblib.load(MODELS / "best_model.joblib")
    X, y, base = build_dataset(load_raw())
    _, X_te, _, y_te, _ = chronological_split(X, y, base, TEST_FRACTION)
    sample = min(3000, len(X_te))

    r = permutation_importance(
        bundle["model"], X_te.iloc[:sample], y_te.iloc[:sample],
        n_repeats=5, random_state=0, n_jobs=-1,
    )
    order = np.argsort(r.importances_mean)[-top_n:]
    fig, ax = plt.subplots(figsize=(8, 6.5))
    ax.barh(np.array(X_te.columns)[order], r.importances_mean[order])
    ax.set_title(f"Permutation importance — {bundle['name']}")
    ax.set_xlabel("Drop in score when the feature is shuffled")
    fig.tight_layout()
    fig.savefig(REPORTS / "feature_importance.png", dpi=130)
    plt.close(fig)


def error_by_hour(df: pd.DataFrame) -> None:
    by_hour = (df["predicted"] - df["actual"]).abs().groupby(df.index.hour).mean()
    print("\nMean absolute error by hour of day:")
    for h, v in by_hour.items():
        print(f"  {h:02d}:00  {v:6.2f}  {'#' * int(v)}")


def main() -> None:
    df = load_predictions()
    plot_timeseries(df)
    plot_scatter_and_residuals(df)
    plot_importance(df)
    error_by_hour(df)
    print(f"\nPlots written to {REPORTS}")


if __name__ == "__main__":
    main()
