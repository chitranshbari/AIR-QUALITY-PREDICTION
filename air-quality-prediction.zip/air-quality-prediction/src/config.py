"""Central configuration. Change things here, not scattered through the code."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_RAW = ROOT / "data" / "raw"
DATA_PROCESSED = ROOT / "data" / "processed"
MODELS = ROOT / "models"
REPORTS = ROOT / "reports"

for _d in (DATA_RAW, DATA_PROCESSED, MODELS, REPORTS):
    _d.mkdir(parents=True, exist_ok=True)

# UCI "Beijing PM2.5 Data" — hourly pollution + weather, 2010-2014.
DATA_URL = "https://archive.ics.uci.edu/static/public/381/beijing+pm2+5+data.zip"
RAW_CSV = DATA_RAW / "beijing_pm25.csv"

TARGET = "pm25"
HORIZON = 1          # predict pollution 1 hour ahead
TEST_FRACTION = 0.2  # last 20% of the timeline is the test set
RANDOM_STATE = 42
