"""Step 1 — get the data.

Tries the public UCI dataset first. If there's no internet (offline machine,
college wifi blocking it), it falls back to a synthetic dataset with the same
columns and realistic seasonal/daily patterns, so the rest of the pipeline
always runs.
"""
from __future__ import annotations

import io
import zipfile

import numpy as np
import pandas as pd

from config import DATA_URL, RAW_CSV, RANDOM_STATE

COLUMNS = {
    "pm2.5": "pm25",
    "DEWP": "dew_point",
    "TEMP": "temp",
    "PRES": "pressure",
    "cbwd": "wind_dir",
    "Iws": "wind_speed",
    "Is": "snow_hours",
    "Ir": "rain_hours",
}


def download() -> bool:
    """Fetch the UCI archive. Returns False if it can't be reached."""
    try:
        import urllib.request

        req = urllib.request.Request(
            DATA_URL, headers={"User-Agent": "Mozilla/5.0 (air-quality-project)"}
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            blob = resp.read()
        with zipfile.ZipFile(io.BytesIO(blob)) as zf:
            name = [n for n in zf.namelist() if n.endswith(".csv")][0]
            RAW_CSV.write_bytes(zf.read(name))
        print(f"Downloaded dataset -> {RAW_CSV}")
        return True
    except Exception as exc:  # offline, proxy, moved URL...
        print(f"Could not download dataset ({exc.__class__.__name__}: {exc}).")
        return False


def make_synthetic(n_hours: int = 24 * 365 * 3) -> pd.DataFrame:
    """Fallback data. Same shape as the real thing, generated from a simple
    model: seasonal + daily cycles, weather effects, and autocorrelated noise."""
    rng = np.random.default_rng(RANDOM_STATE)
    idx = pd.date_range("2018-01-01", periods=n_hours, freq="h")
    t = np.arange(n_hours)

    yearly = np.sin(2 * np.pi * (t / (24 * 365)) - 1.2)
    daily = np.sin(2 * np.pi * (t / 24) - 0.8)

    temp = 18 + 12 * yearly * -1 + 4 * daily + rng.normal(0, 2, n_hours)
    pressure = 1013 - 6 * yearly + rng.normal(0, 3, n_hours)
    dew_point = temp - rng.gamma(3, 2, n_hours)
    wind_speed = np.abs(rng.gamma(2, 3, n_hours))
    wind_dir = rng.choice(["NW", "NE", "SE", "cv"], n_hours, p=[0.3, 0.2, 0.3, 0.2])
    rain_hours = (rng.random(n_hours) < 0.04) * rng.integers(1, 6, n_hours)
    snow_hours = (rng.random(n_hours) < 0.01) * rng.integers(1, 4, n_hours)

    # pollution: high in winter, peaks morning/evening, washed out by wind & rain
    base = 80 + 55 * yearly + 18 * np.sin(2 * np.pi * (t / 24) - 2.0)
    base = base - 2.2 * wind_speed - 4.0 * rain_hours

    noise = np.zeros(n_hours)
    eps = rng.normal(0, 14, n_hours)
    for i in range(1, n_hours):  # AR(1): pollution is sticky hour to hour
        noise[i] = 0.92 * noise[i - 1] + eps[i]

    pm25 = np.clip(base + noise, 2, None)
    pm25[rng.random(n_hours) < 0.02] = np.nan  # realistic sensor gaps

    print("Using synthetic dataset (offline fallback).")
    return pd.DataFrame(
        {
            "pm25": pm25,
            "dew_point": dew_point,
            "temp": temp,
            "pressure": pressure,
            "wind_dir": wind_dir,
            "wind_speed": wind_speed,
            "snow_hours": snow_hours,
            "rain_hours": rain_hours,
        },
        index=idx,
    )


def load_raw() -> pd.DataFrame:
    """Return a clean, hourly-indexed dataframe."""
    if not RAW_CSV.exists():
        download()

    if RAW_CSV.exists():
        df = pd.read_csv(RAW_CSV)
        df["datetime"] = pd.to_datetime(df[["year", "month", "day", "hour"]])
        df = df.set_index("datetime").sort_index()
        df = df[list(COLUMNS)].rename(columns=COLUMNS)
    else:
        df = make_synthetic()

    # The target is missing for ~4% of hours. Interpolating short gaps is fine;
    # dropping long ones is safer than inventing days of data.
    df["pm25"] = df["pm25"].interpolate(limit=3)
    df = df.dropna(subset=["pm25"])
    df = df.ffill()
    return df


if __name__ == "__main__":
    d = load_raw()
    print(d.shape)
    print(d.head())
    print(d.describe().round(2))
