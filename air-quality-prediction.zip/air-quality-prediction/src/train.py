"""Step 3 — train and compare models, then save the best one.

Run:  python src/train.py
"""
from __future__ import annotations

import json
import time

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, r2_score, root_mean_squared_error
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from config import MODELS, RANDOM_STATE, REPORTS, TEST_FRACTION
from data import load_raw
from features import build_dataset, chronological_split


def metrics(y_true, y_pred) -> dict:
    return {
        "MAE": float(mean_absolute_error(y_true, y_pred)),
        "RMSE": float(root_mean_squared_error(y_true, y_pred)),
        "R2": float(r2_score(y_true, y_pred)),
    }


def get_models(n_jobs: int = -1) -> dict:
    return {
        # Linear model — fast, interpretable, a strong sanity check.
        "ridge": make_pipeline(StandardScaler(), Ridge(alpha=1.0)),
        # Bagged trees — handles non-linearity, no scaling needed.
        "random_forest": RandomForestRegressor(
            n_estimators=200, max_depth=None, min_samples_leaf=2,
            n_jobs=n_jobs, random_state=RANDOM_STATE,
        ),
        # Boosted trees — usually the winner on tabular data.
        "hist_gradient_boosting": HistGradientBoostingRegressor(
            max_iter=400, learning_rate=0.06, max_depth=None,
            early_stopping=True, random_state=RANDOM_STATE,
        ),
    }


def main() -> None:
    print("Loading data...")
    raw = load_raw()
    X, y, baseline = build_dataset(raw)
    X_tr, X_te, y_tr, y_te, base_te = chronological_split(X, y, baseline, TEST_FRACTION)
    print(f"Train: {len(X_tr):,} rows  Test: {len(X_te):,} rows  Features: {X.shape[1]}")
    print(f"Train period: {X_tr.index.min()} -> {X_tr.index.max()}")
    print(f"Test  period: {X_te.index.min()} -> {X_te.index.max()}\n")

    results = {"persistence_baseline": metrics(y_te, base_te)}
    print(f"{'model':<26}{'MAE':>9}{'RMSE':>9}{'R2':>8}{'fit s':>9}")
    print("-" * 61)
    b = results["persistence_baseline"]
    print(f"{'persistence (baseline)':<26}{b['MAE']:>9.2f}{b['RMSE']:>9.2f}{b['R2']:>8.3f}{'-':>9}")

    fitted = {}
    for name, model in get_models().items():
        t0 = time.time()
        model.fit(X_tr, y_tr)
        elapsed = time.time() - t0
        m = metrics(y_te, model.predict(X_te))
        m["fit_seconds"] = round(elapsed, 1)
        results[name] = m
        fitted[name] = model
        print(f"{name:<26}{m['MAE']:>9.2f}{m['RMSE']:>9.2f}{m['R2']:>8.3f}{elapsed:>9.1f}")

    best_name = min(fitted, key=lambda n: results[n]["RMSE"])
    best = fitted[best_name]
    improvement = 100 * (1 - results[best_name]["RMSE"] / results["persistence_baseline"]["RMSE"])
    print(f"\nBest model: {best_name}  ({improvement:.1f}% lower RMSE than the naive baseline)")

    joblib.dump(
        {"model": best, "name": best_name, "features": list(X.columns)},
        MODELS / "best_model.joblib",
    )
    (REPORTS / "metrics.json").write_text(json.dumps(results, indent=2))

    # Keep the test-set predictions so evaluate.py doesn't have to retrain.
    pd.DataFrame(
        {"actual": y_te, "predicted": best.predict(X_te), "baseline": base_te},
        index=y_te.index,
    ).to_csv(REPORTS / "test_predictions.csv")

    print(f"Saved model -> {MODELS / 'best_model.joblib'}")
    print(f"Saved metrics -> {REPORTS / 'metrics.json'}")


if __name__ == "__main__":
    main()
