"""Step 2 — turn a time series into a supervised learning table.

The single most important idea in this project: a model can only use
information that would actually exist at prediction time. Every feature here
is built from the *past*; the target is shifted from the *future*.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from config import HORIZON, TARGET

LAGS = [1, 2, 3, 6, 12, 24, 48]
ROLLING_WINDOWS = [3, 12, 24]


def add_time_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    idx = df.index
    df["hour"] = idx.hour
    df["dayofweek"] = idx.dayofweek
    df["month"] = idx.month
    df["is_weekend"] = (idx.dayofweek >= 5).astype(int)
    # Cyclic encoding: hour 23 and hour 0 should be close together, and the
    # raw number 23 vs 0 is not. Sin/cos pairs fix that.
    df["hour_sin"] = np.sin(2 * np.pi * df["hour"] / 24)
    df["hour_cos"] = np.cos(2 * np.pi * df["hour"] / 24)
    df["month_sin"] = np.sin(2 * np.pi * df["month"] / 12)
    df["month_cos"] = np.cos(2 * np.pi * df["month"] / 12)
    return df


def add_lag_features(df: pd.DataFrame, col: str = TARGET) -> pd.DataFrame:
    df = df.copy()
    for lag in LAGS:
        df[f"{col}_lag{lag}"] = df[col].shift(lag)
    for w in ROLLING_WINDOWS:
        roll = df[col].shift(1).rolling(w)  # shift(1) first = no peeking
        df[f"{col}_rollmean{w}"] = roll.mean()
        df[f"{col}_rollstd{w}"] = roll.std()
    df[f"{col}_diff1"] = df[col].diff(1)
    df["temp_lag1"] = df["temp"].shift(1)
    df["wind_speed_lag1"] = df["wind_speed"].shift(1)
    return df


def build_dataset(df: pd.DataFrame, horizon: int = HORIZON):
    """Returns X, y, and the timestamps each row refers to."""
    df = add_time_features(df)
    df = add_lag_features(df)
    df = pd.get_dummies(df, columns=["wind_dir"], prefix="wind", dtype=int)

    df["target"] = df[TARGET].shift(-horizon)   # value we want to predict
    df["persistence"] = df[TARGET]              # naive baseline: "same as now"
    df = df.dropna()

    y = df["target"]
    baseline = df["persistence"]
    X = df.drop(columns=["target", "persistence"])
    return X, y, baseline


def chronological_split(X, y, baseline, test_fraction: float):
    """Never shuffle a time series. Train on the past, test on the future."""
    cut = int(len(X) * (1 - test_fraction))
    return (
        X.iloc[:cut], X.iloc[cut:],
        y.iloc[:cut], y.iloc[cut:],
        baseline.iloc[cut:],
    )
